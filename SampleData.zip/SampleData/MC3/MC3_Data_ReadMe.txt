MC3 will contain one CSV file, spanning from 04/06/2020 - 04/12/2020, which has the following fields:
	- time (date/time the message was posted)
	- location (St. Himark neighborhood message was posted from)
	- account (user handle of the person who posted the message)
	- message (text of the message itself)
	
Be prepared to have to discern between reliable and unreliable messages.

