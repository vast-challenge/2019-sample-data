You can create your answer submission either directly in the htm file or in the Word document and exported as html. If done in Word, please ensure all links work correctly.

Thank you